/**
   io.h - v0.1 - 01/02/2019
   @uthor  : PUC-Minas - ICEI - CRC
   @version: 0.1
   All rights reserved.

   Windows installation:
    copy file io.h    to include folder
    copy file libio.a to lib     folder

   Include:
   #include <io.h>

   Compile:
   gcc -o test_io.exe test_io.c -lio

   Run:
   test_io
 */
// dependencias

#include "io.h"

int IO_error = 0;                   // sem erros

/**
    Metodo para limpar a entrada de dados (terminal).
 */
void IO_flush ( )
{
    int c = '_';

#if defined (unix) || defined (_unix) || defined (_unix)
    stdin = freopen ( NULL,"r",stdin );
#else
    fflush ( stdin );       // for Windows
#endif
} // fim IO_flush ( )

/**
    Metodo para limpar a tela (terminal).
 */
void IO_clrscr ( )
{
#if defined (unix) || defined (_unix) || defined (_unix)
    if (! getenv ("JGRASP_INSIDE") )
    {  printf ( "\033c" ); } // for Linux
    else 
    {  printf ( "\n" );    } // inside JGrasp   
#endif
#if defined (WIN32) || defined (_WIN32) || defined (Windows_NT) 
    if (! getenv ("JGRASP_INSIDE") )
    {  system ( "cls" );   } // for Windows
    else 
    {  printf ( "\n" );    } // inside JGrasp   
#endif
} // fim IO_clrscr ( )

/**
    Funcao para informar a versao atual da IO.
    @return versao da IO
 */
chars IO_version ( )
{
  chars version = { "0.1" };
  return ( version );
} // fim IO_version ( )

/**
    Metodo para identificar o programa e a autoria.
    @param text - mensagem a ser exibida
 */
void IO_id ( chars text )
{
    printf ( "%s\n", text );
    printf ( "%s\n", "Autor: ________________________" );
    printf ( "\n" );          // mudar de linha
} // fim IO_id ( )

/**
    Funcao para reservar espaco para guardar cadeia de caracteres.
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
chars IO_new_chars ( int size )
{
    return ( (chars) malloc ( (size+1)*sizeof(char) ) );
} // fim IO_new_chars ( )

/**
    Funcao para reservar espaco para guardar inteiros.
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
ints IO_new_ints ( int size )
{
    return ( (ints) malloc ( (size)*sizeof(int) ) );
} // fim IO_new_ints ( )

/**
    Funcao para reservar espaco para guardar reais (precisao dupla).
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
doubles IO_new_doubles ( int size )
{
    return ( (doubles) malloc ( (size)*sizeof(double) ) );
} // fim IO_new_doubles ( )

/**
    Funcao para reservar espaco para guardar reais (precisao simples).
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
floats IO_new_floats ( int size )
{
    return ( (floats) malloc ( (size)*sizeof(float) ) );
} // fim IO_new_floats ( )

/**
    Funcao para reservar espaco para guardar logicos.
    @return area reservada, se houver; NULL, caso contrario
    @param size - quantidade de dados
 */
bools IO_new_bools ( int size )
{
    return ( (bools) malloc ( (size)*sizeof(bool) ) );
} // fim IO_new_bools ( )

/**
    Funcao para concatenar cadeias de caracteres.
    @return cadeia com o resultado
    @param text1 - primeira cadeia
    @param text2 - segunda  cadeia
 */
chars IO_concat ( chars text1, chars text2 )
{                               // reservar area
  chars buffer = IO_new_chars ( strlen(text1)+strlen(text2)+1 );
  strcpy ( buffer, text1 );
  strcat ( buffer, text2 );
  return ( buffer );
} // fim IO_concat ( )

/**
    Funcao para converter valor logico para caracteres.
    @return cadeia com o resultado
    @param x     - valor logico
 */
chars IO_toString_b ( bool x )
{                               // reservar area
  chars buffer = IO_new_chars ( STR_SIZE+1 );
                                // variante do printf( )
  sprintf ( buffer, "%d", x );
  return  ( buffer );
} // fim IO_toString_b ( )

/**
    Funcao para converter caractere para caracteres.
    @return cadeia com o resultado
    @param x     - caractere
 */
chars IO_toString_c ( char x )
{                             // variante do printf( )
  chars buffer = IO_new_chars ( STR_SIZE+1 );
  sprintf ( buffer, "%c", x );
  return  ( buffer );
} // fim IO_toString_c ( )

/**
    Funcao para converter inteiro para caracteres.
    @return cadeia com o resultado
    @param x     - valor inteiro
 */
chars IO_toString_d ( int x )
{                             // variante do printf( )
  chars buffer = IO_new_chars ( STR_SIZE+1 );
  sprintf ( buffer, "%d", x );
  return  ( buffer );
} // fim IO_toString_d ( )

/**
    Funcaoo para converter real para caracteres.
    @return cadeia com o resultado
    @param x     - valor real
 */
chars IO_toString_f ( double x )
{                             // variante do printf( )
  chars buffer = IO_new_chars ( STR_SIZE+1 );
  sprintf ( buffer, "%lf", x );
  return  ( buffer );
} // fim IO_toString_f ( )

/**
    Metodo para mostrar uma linha com certo texto.
    @param text1 - primeira cadeia
 */
void IO_print ( chars text1 )
{
  printf ( "%s", text1 );
} // fim IO_print ( )

/**
    Metodo para mostrar uma linha com certo texto
    e mudar de linha.
    @param text1 - primeira cadeia
 */
void IO_println ( chars text1 )
{
  printf ( "%s\n", text1 );
} // fim IO_println ( )

/**
    Metodo para gravar uma linha em arquivo texto.
    @param filePtr - referencia para arquivo aberto
    @param text1 - cadeia de caracteres a ser gravada
 */
void IO_fprint ( FILE* filePtr, chars text1 )
{
  fprintf ( filePtr, "%s", text1 );
} // fim IO_fprint ( )

/**
    Metodo para gravar uma linha em arquivo texto
    e mudar de linha.
    @param filePtr - referencia para arquivo aberto
    @param text1 - cadeia de caracteres a ser gravada
 */
void IO_fprintln ( FILE* filePtr, chars text1 )
{
  fprintf ( filePtr, "%s\n", text1 );
} // fim IO_fprintln ( )

/**
    Funcao para ler valor inteiro.
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
bool IO_readbool ( chars text1 )
{
  int x = 0;

  printf ( "%s", text1 );
  IO_flush ( );
//  fflush ( stdin );           // limpar a entrada de dados
  scanf  ( "%d", &x );        // ler valor logico

  return ( x!=0 );
} // fim IO_readbool ( )

/**
    Funcao para caractere.
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
char IO_readchar ( chars text1 )
{
  char x = '_';

  printf ( "%s", text1 );
  IO_flush ( );
//  fflush ( stdin );           // limpar a entrada de dados
  scanf  ( "%c", &x );        // ler caractere

  return ( x );
} // fim IO_readchar ( )

/**
    Funcao para ler valor real (precisao dupla).
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
double IO_readdouble ( chars text1 )
{
  double x = 0.0;

  printf ( "%s", text1 );
  IO_flush ( );
//  fflush ( stdin );           // limpar a entrada de dados
  scanf  ( "%lf", &x );       // ler valor real

  return ( x );
} // fim IO_readdouble ( )

/**
    Funcao para ler valor real (precisao simples).
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
float IO_readfloat ( chars text1 )
{
  float x = 0.0;

  printf ( "%s", text1 );
  IO_flush ( );
//  fflush ( stdin );           // limpar a entrada de dados
  scanf  ( "%f", &x );        // ler valor real

  return ( x );
} // fim IO_readfloat ( )

/**
    Funcao para ler valor inteiro.
    @return valor lido
    @param text1 - mensagem a ser exibida antes da leitura
 */
int IO_readint ( chars text1 )
{
  int x = 0;

  printf ( "%s", text1 );
  IO_flush ( );
//  fflush ( stdin );           // limpar a entrada de dados
  scanf  ( "%d", &x );        // ler valor inteiro

  return ( x );
} // fim IO_readint ( )

/**
    Funcao para ler cadeia de caracteres.
    @return cadeia de caracteres
    @param text1 - mensagem a ser exibida antes da leitura
 */
chars IO_readstring ( chars text1 )
{
  chars buffer = IO_new_chars ( STR_SIZE+1 );

  printf ( "%s", text1 );
  IO_flush ( );
// fflush ( stdin );           // limpar a entrada de dados
  scanf  ( "%s", buffer );    // ler cadeia de caracteres

  return ( buffer );
} // fim IO_readstring ( )

/**
    Funcao para ler uma linha inteira.
    @return linha lida
    @param text1 - mensagem a ser exibida antes da leitura
 */
chars IO_readln ( chars text1 )
{
  chars buffer = (chars) malloc ( 1024*sizeof(char) );

  printf ( "%s", text1 );
  IO_flush ( );
//  fflush ( stdin );
  fgets  ( buffer, 1024, stdin );
  if ( strlen( buffer ) > STR_SIZE )
  {
     buffer[STR_SIZE-1] = '\0'; // limitar ao tamanho maximo
  }
  if ( strlen( buffer ) > 0 )
  {
     buffer[ strlen(buffer)-1] = '\0'; // tirar o '\n'
  }
  return ( buffer );
} // fim IO_readln ( )

/**
    Metodo para indicar uma pausa (esperar por ENTER).
    @param text - mensagem a ser exibida antes da espera
 */
void IO_pause ( chars text )
{
    printf ( "\n\n%s", text );
    fflush ( stdin );         // limpar a entrada de dados
    getchar( );               // aguardar por ENTER
} // fim IO_pause ( )

/**
    Funcao para ler uma palavra de arquivo.
    @return palavra lida
    @param arquivo - referencia para arquivo aberto
 */
chars IO_fread ( FILE* filePtr )
{
  chars buffer = IO_new_chars ( STR_SIZE+1 );

  fscanf ( filePtr, "%s", buffer ); // ler uma linha
  return ( buffer );
} // fim IO_fread ( )

/**
    Funcao para ler uma linha inteira.
    @return linha lida
    @param filePtr - referencia para arquivo aberto
 */
chars IO_freadln ( FILE* filePtr )
{
  chars buffer = IO_new_chars ( STR_SIZE+1 );

  fgets  ( buffer, STR_SIZE, filePtr ); // ler uma linha
  buffer [ strlen (buffer)-1 ] = EOS;   // reposicionar o fim de linha
  return ( buffer );
} // fim IO_freadln ( )

// ----------------------------------------------- debug definitions

/**
    Controle do acesso ao modo de depuracao.
 */
static bool __DEBUG__ = false;

/**
    Indicador do modo de depuracao.
 */
chars _DEBUG_PROMPT_ = "DBG> ";

#define __debug_here__ __FILE__,__FUNCTION__,__LINE__

#define _BREAKPOINT_ SE ( __DEBUG__ )                            \
                        TELA ( "\n[%s:%s:%d]", __debug_here__ ); \
                        PAUSA;                                   \
                     FIM_SE

#define _DEBUG_ON_   __DEBUG__ = true ;
#define _DEBUG_OFF_  __DEBUG__ = false;

/**
    Metodo para auxiliar na depuracao.
    @param test   - valor ou condicao a ser avaliada
    @param format - formato para os valores a serem exibidos
    @param ...    - valores a serem exibidos
 */
void IO_debug ( int test, const chars format, ... )
{
  if ( __DEBUG__ )
  {
     printf ( "\n%s ", _DEBUG_PROMPT_ );
     if ( test )
     {
        va_list ptr;
        va_start( ptr, format );
        vprintf ( format, ptr );
        va_end  ( ptr );
     }
     fflush ( stdin );
     getchar ( );
  }
}
