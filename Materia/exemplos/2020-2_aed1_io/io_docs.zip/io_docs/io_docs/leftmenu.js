function WriteLeftMenu(divID, aID, divClassName, aClassName)
{
document.write("<div id=\"divID0\" class=\"headerLeftMenuInActive\"><a id=\"aID0\" href=\"#\" OnMouseOver=\"link('','index',this)\" class=\"leftMenuLinkHeadInActive\">Default mainpage</a></div>\n");
document.write("<div id='leftmenutree' class='treeLeftMenu'>\n");
var treeLeftMenu = new TreeClass('treeLeftMenu', false);
treeLeftMenu.setTreeHeightDelta(-205);
treeLeftMenu.m_iDefaultExpandedLevel = 1;treeLeftMenu.setExpandCollapseNames('Expand All','Collapse All');
treeLeftMenu.startTree( true );
  treeLeftMenu.startParentNode('Default mainpage','"#"','','common/directoryBlue', { "onmouseover":"link('','index',this);" });
  treeLeftMenu.startParentNode('io','"#"','','common/directoryBlue', { "onmouseover":"link('_dir','io/io0',this);" });
  treeLeftMenu.startParentNode('Functions','"#"','','common/functionsBlue');
  treeLeftMenu.addNode('IO_clrscr','"#"','','common/function', { "onmouseover":"link('_member','io/IO_clrscr122',this);" });
  treeLeftMenu.addNode('IO_concat','"#"','','common/function', { "onmouseover":"link('_member','io/IO_concat35125896',this);" });
  treeLeftMenu.addNode('IO_debug','"#"','','common/function', { "onmouseover":"link('_member','io/IO_debug1128263206',this);" });
  treeLeftMenu.addNode('IO_flush','"#"','','common/function', { "onmouseover":"link('_member','io/IO_flush122',this);" });
  treeLeftMenu.addNode('IO_fprint','"#"','','common/function', { "onmouseover":"link('_member','io/IO_fprint2467077857',this);" });
  treeLeftMenu.addNode('IO_fprintln','"#"','','common/function', { "onmouseover":"link('_member','io/IO_fprintln2467077857',this);" });
  treeLeftMenu.addNode('IO_fread','"#"','','common/function', { "onmouseover":"link('_member','io/IO_fread86128753',this);" });
  treeLeftMenu.addNode('IO_freadln','"#"','','common/function', { "onmouseover":"link('_member','io/IO_freadln86128753',this);" });
  treeLeftMenu.addNode('IO_id','"#"','','common/function', { "onmouseover":"link('_member','io/IO_id154236',this);" });
  treeLeftMenu.addNode('IO_new_bools','"#"','','common/function', { "onmouseover":"link('_member','io/IO_new_bools60979',this);" });
  treeLeftMenu.addNode('IO_new_chars','"#"','','common/function', { "onmouseover":"link('_member','io/IO_new_chars60979',this);" });
  treeLeftMenu.addNode('IO_new_doubles','"#"','','common/function', { "onmouseover":"link('_member','io/IO_new_doubles60979',this);" });
  treeLeftMenu.addNode('IO_new_floats','"#"','','common/function', { "onmouseover":"link('_member','io/IO_new_floats60979',this);" });
  treeLeftMenu.addNode('IO_new_ints','"#"','','common/function', { "onmouseover":"link('_member','io/IO_new_ints60979',this);" });
  treeLeftMenu.addNode('IO_pause','"#"','','common/function', { "onmouseover":"link('_member','io/IO_pause154236',this);" });
  treeLeftMenu.addNode('IO_print','"#"','','common/function', { "onmouseover":"link('_member','io/IO_print154236',this);" });
  treeLeftMenu.addNode('IO_println','"#"','','common/function', { "onmouseover":"link('_member','io/IO_println154236',this);" });
  treeLeftMenu.addNode('IO_readbool','"#"','','common/function', { "onmouseover":"link('_member','io/IO_readbool154236',this);" });
  treeLeftMenu.addNode('IO_readchar','"#"','','common/function', { "onmouseover":"link('_member','io/IO_readchar154236',this);" });
  treeLeftMenu.addNode('IO_readdouble','"#"','','common/function', { "onmouseover":"link('_member','io/IO_readdouble154236',this);" });
  treeLeftMenu.addNode('IO_readfloat','"#"','','common/function', { "onmouseover":"link('_member','io/IO_readfloat154236',this);" });
  treeLeftMenu.addNode('IO_readint','"#"','','common/function', { "onmouseover":"link('_member','io/IO_readint154236',this);" });
  treeLeftMenu.addNode('IO_readln','"#"','','common/function', { "onmouseover":"link('_member','io/IO_readln154236',this);" });
  treeLeftMenu.addNode('IO_readstring','"#"','','common/function', { "onmouseover":"link('_member','io/IO_readstring154236',this);" });
  treeLeftMenu.addNode('IO_toString_b','"#"','','common/function', { "onmouseover":"link('_member','io/IO_toString_b56656',this);" });
  treeLeftMenu.addNode('IO_toString_c','"#"','','common/function', { "onmouseover":"link('_member','io/IO_toString_c49468',this);" });
  treeLeftMenu.addNode('IO_toString_d','"#"','','common/function', { "onmouseover":"link('_member','io/IO_toString_d60979',this);" });
  treeLeftMenu.addNode('IO_toString_f','"#"','','common/function', { "onmouseover":"link('_member','io/IO_toString_f86422002',this);" });
  treeLeftMenu.addNode('IO_version','"#"','','common/function', { "onmouseover":"link('_member','io/IO_version122',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Defines','"#"','','common/definesBlue');
  treeLeftMenu.addNode('IO_printf','"#"','','common/define', { "onmouseover":"link('_member','io/IO_printf1542553574',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Attributes','"#"','','common/attributesBlue');
  treeLeftMenu.addNode('__DEBUG__','"#"','','common/variable', { "onmouseover":"link('_member','io/__DEBUG__0',this);" });
  treeLeftMenu.addNode('_DEBUG_PROMPT_','"#"','','common/variable', { "onmouseover":"link('_member','io/_DEBUG_PROMPT_0',this);" });
  treeLeftMenu.addNode('IO_error','"#"','','common/variable', { "onmouseover":"link('_member','io/IO_error_29',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Types','"#"','','common/typesBlue');
  treeLeftMenu.addNode('bools','"#"','','common/type', { "onmouseover":"link('_member','io/bools0',this);" });
  treeLeftMenu.addNode('chars','"#"','','common/type', { "onmouseover":"link('_member','io/chars0',this);" });
  treeLeftMenu.addNode('doubles','"#"','','common/type', { "onmouseover":"link('_member','io/doubles0',this);" });
  treeLeftMenu.addNode('floats','"#"','','common/type', { "onmouseover":"link('_member','io/floats0',this);" });
  treeLeftMenu.addNode('ints','"#"','','common/type', { "onmouseover":"link('_member','io/ints0',this);" });
treeLeftMenu.endParentNode();
treeLeftMenu.endParentNode();
treeLeftMenu.endParentNode();
treeLeftMenu.endTree();
treeLeftMenu.readStateFromCookie();
document.write("</div>\n");
document.write("<div class=\"paragraphLeftMenu\">Miscellaneous</div>\n");
document.write("<div id=\"divID20\" class=\"leftMenuTreeInActive\"><a id=\"aID20\" href=\"#\" OnMouseOver=\"link('_statsindex','common/statistics/index',this)\" class=\"leftMenuLinkInActive\">Statistics</a></div>\n");
if(divID != "" && aID != "")
{
  var elemDiv = document.getElementById(divID);
  var elemA = document.getElementById(aID);
  if (elemDiv != undefined && elemA != undefined ) { // this is needed to abvoid crashing js on some memberpages 
    elemDiv.className = divClassName;
    elemA.className = aClassName;
  }
}
}
